'use-strict'

const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp(functions.config().firebase);

exports.sendNotification = functions.firestore.document("ServiceProviders/{spId}/Users/{user_id}/Notifications/{notification_id}").onWrite((data, context) => {

    const spId = context.params.spId;
    const user_id = context.params.user_id;
    const notification_id = context.params.notification_id

    return admin.firestore().collection("ServiceProviders").doc(spId).collection("Users").doc(user_id).collection("Notifications").doc(notification_id).get().then(queryResult =>{

        const from_user_id = queryResult.data().from;
        const from_message = queryResult.data().message;
        const from_spName = queryResult.data().spName;

        const from_data = admin.firestore().collection("ServiceProviders").doc(spId).collection("Users").doc(from_user_id).get();
        const to_data = admin.firestore().collection("ServiceProviders").doc(spId).collection("Users").doc(user_id).get();

        return Promise.all([from_data, to_data]).then(result1 => {

          const from_name = result1[0].data().name;
          const to_name = result1[1].data().name;
          const token_id = result1[1].data().token_id;

          const payload = {
            notification:{
              title: "Notification From: "+ from_spName,
              body: from_message,
              icon: "default",
              click_action:"com.mad.buzzme.TARGETNOTIFICATION"
            },
            data:{
              message: from_message,
              from_user_id: from_spName,
              spName: from_spName
            }
          };
          return admin.messaging().sendToDevice(token_id, payload).then(result => {
            console.log("success");
            return true;
          })
        });

    });
});
