package com.mad.buzzme.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.bumptech.glide.Glide;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.mad.buzzme.R;
import com.mad.buzzme.activities.OrderManagementActivity;
import com.mad.buzzme.adapters.UserRecyclerAdapter;
import com.mad.buzzme.model.ServiceProvider;
import com.mad.buzzme.model.User;
import com.mad.buzzme.viewholders.OrderManagementViewHolder;

import java.util.ArrayList;
import java.util.List;

public class QueueFragment extends Fragment{

    //Init views and backends
    private RecyclerView mQueueListView;
    private List<User> users;
    private UserRecyclerAdapter userRecyclerAdapter;
    public String spID = "null";
    public String spName = "null";
    private final String SERVICE_PROVIDER = "SERVICE PROVIDER";
    private Button viewOrderBtn;

    private FirebaseFirestore mFireStore;


    public QueueFragment(){
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_queue, container, false);

        mQueueListView = (RecyclerView) view.findViewById(R.id.queueListView);

        //Init backend
        mFireStore = FirebaseFirestore.getInstance();

        //Getting the data from bundle
        final Bundle bundle = this.getArguments();
        if (bundle != null) {
            ServiceProvider serviceProvider = (ServiceProvider) bundle.getParcelable(SERVICE_PROVIDER);
            spID = serviceProvider.getSpId();
            spName = serviceProvider.getSpname();
        }

        //The View order button will take user to the OrderManamentActivity
        viewOrderBtn = (Button) view.findViewById(R.id.viewOrderBtn);
        viewOrderBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent viewOrderIntent = new Intent(getActivity(), OrderManagementActivity.class);
                viewOrderIntent.putExtra("spId", spID);
                startActivity(viewOrderIntent);
            }
        });
        users = new ArrayList<>();
        userRecyclerAdapter = new UserRecyclerAdapter(container.getContext(),users, this);

        //Setup the list View
        mQueueListView.setHasFixedSize(true);
        mQueueListView.setLayoutManager(new LinearLayoutManager(container.getContext()));
        mQueueListView.setAdapter(userRecyclerAdapter);

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        //Clear the user list so it does not get duplicated
        users.clear();

        //Load the users into the recycler adapter
        mFireStore.collection("ServiceProviders").document(spID).collection("Users").addSnapshotListener(getActivity(), new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@javax.annotation.Nullable QuerySnapshot queryDocumentSnapshots, @javax.annotation.Nullable FirebaseFirestoreException e) {
                for (DocumentChange doc: queryDocumentSnapshots.getDocumentChanges()){
                    if(doc.getType() == DocumentChange.Type.ADDED){

                        User user = doc.getDocument().toObject(User.class);
                        users.add(user);

                        userRecyclerAdapter.notifyDataSetChanged();
                    }
                }
            }
        });
    }
}
