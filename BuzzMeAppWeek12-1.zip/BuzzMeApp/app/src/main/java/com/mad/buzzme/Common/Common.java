package com.mad.buzzme.Common;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;

import com.mad.buzzme.R;

public class Common {
    //Contain String used across all the activity
    public static final String UPDATE = "Update";
    public static final String DELETE = "Delete";
}
