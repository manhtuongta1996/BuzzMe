package com.mad.buzzme.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.mad.buzzme.R;

import org.w3c.dom.Text;

public class NotificationActivity extends AppCompatActivity {
    //Init Views
    private TextView mNotifData;

    /*
     * This activity will simply let the user know that they have been notified by the service providers
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        String dataMessage = getIntent().getStringExtra("message");
       // String dataFrom = getIntent().getStringExtra("from_user_id");
       // String dataServiceProvider = getIntent().getStringExtra("spName");

        mNotifData = (TextView) findViewById(R.id.notifData);
        //Display message
        mNotifData.setText(" | MESSAGE: "+dataMessage);
        }
}
