package com.mad.buzzme.viewholders;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.mad.buzzme.Common.Common;
import com.mad.buzzme.R;
import com.mad.buzzme.interfaces.ItemClickListener;

public class OrderManagementViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener,View.OnCreateContextMenuListener {


    public TextView txtOrderId;
    public TextView txtOrderStatus;
    public TextView txtOrderName;
    public Button updateStatusBtn;

    private ItemClickListener itemClickListener;

    public OrderManagementViewHolder(@NonNull View itemView) {
        super(itemView);

        txtOrderId = (TextView) itemView.findViewById(R.id.order_id);
        txtOrderStatus = (TextView) itemView.findViewById(R.id.order_status);
        txtOrderName = (TextView) itemView.findViewById(R.id.order_name);
        updateStatusBtn = (Button) itemView.findViewById(R.id.updateStatusBtn);

        itemView.setOnClickListener(this);
        itemView.setOnCreateContextMenuListener(this);

    }

    public void setItemClickListener(ItemClickListener itemClickListener){
        this.itemClickListener = itemClickListener;
    }


    @Override
    public void onClick(View view) {
        itemClickListener.onClick(view,getAdapterPosition(), false);
    }


    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        menu.setHeaderTitle("Select the Action");
        menu.add(0,v.getId(),getAdapterPosition(), "Update");
        menu.add(0,v.getId(),getAdapterPosition(), "Update");
    }
}

