package com.mad.buzzme.fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.mad.buzzme.R;
import com.mad.buzzme.activities.InQueueActivity;

import com.mad.buzzme.model.ServiceProvider;

/*
 * This fragment will show the service provider interface
 */
public class StoreInterfaceFragment extends Fragment {

    //Init  views and variable
    private final String SERVICE_PROVIDER = "SERVICE PROVIDER";
    private ImageView mStoreImg;
    private String mStoreImgUrl;
    private Button mReservationBtn;
    private Button mOrderBtn;
    private FirebaseAuth mAuth;
    private FirebaseUser mCurrentUser;

    public void StoreInterfaceFragment(){

    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //Inflate layout
        View view = inflater.inflate(R.layout.store_interface, container, false);

        //Init backend
        mAuth = FirebaseAuth.getInstance();
        mCurrentUser = mAuth.getCurrentUser();

        mStoreImg = (ImageView) view.findViewById(R.id.storeImg);

        final Bundle bundle = this.getArguments();
        if (bundle != null) {
            final ServiceProvider serviceProvider = (ServiceProvider) bundle.getParcelable(SERVICE_PROVIDER);
            mStoreImgUrl = serviceProvider.getSpImgUrl();
            Glide.with(getActivity()).load(mStoreImgUrl).into(mStoreImg);
            if (mCurrentUser.getUid().equals(serviceProvider.getStaff())){

                //If the user is one of the service provider staff this dialog will show up
                //and allow the staff to access the store Management interface
                final AlertDialog dialog = new AlertDialog.Builder(getActivity())
                        .setTitle(R.string.dialog_title)
                        .setMessage(R.string.staff_dialog)
                        .setPositiveButton(R.string.dialog_positiveBtn, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Bundle bundle = new Bundle();
                                bundle.putParcelable(SERVICE_PROVIDER,serviceProvider);
                                Fragment queueFragment = new QueueFragment();
                                queueFragment.setArguments(bundle);
                                FragmentManager fm = getFragmentManager();
                                FragmentTransaction transaction = fm.beginTransaction();
                                transaction.replace(R.id.content_main, queueFragment);
                                transaction.commit();
                            }
                        })
                        .setNegativeButton(R.string.dialog_negativeBtn, null)
                        .show();


            }
    }

        //Reservation Button will put the user inside the Queue
        mReservationBtn = (Button) view.findViewById(R.id.reservationBtn);
        mReservationBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Intent intent = new Intent(getActivity(), InQueueActivity.class);
            if (bundle != null) {
                ServiceProvider serviceProvider = (ServiceProvider) bundle.getParcelable(SERVICE_PROVIDER);
                intent.putExtra(SERVICE_PROVIDER, serviceProvider);
                startActivity(intent);
                }
            }
        });

        //Order Button will allow the user to access the menu of the service provider
        mOrderBtn = (Button) view.findViewById(R.id.orderBtn);
        mOrderBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Fragment restaurantMenuFragment = new RestaurantMenuFragment();
                Bundle bundle = getArguments();
                if (bundle != null) {
                    final ServiceProvider serviceProvider = (ServiceProvider) bundle.getParcelable(SERVICE_PROVIDER);
                    bundle.putParcelable(SERVICE_PROVIDER, serviceProvider);
                    restaurantMenuFragment.setArguments(bundle);
                    FragmentManager fm = getFragmentManager();
                    FragmentTransaction transaction = fm.beginTransaction();
                    transaction.replace(R.id.content_main, restaurantMenuFragment);
                    transaction.commit();
                }
                }
        });

        return view;
    }
}
