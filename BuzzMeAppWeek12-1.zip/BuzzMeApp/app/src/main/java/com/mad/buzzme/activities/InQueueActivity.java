package com.mad.buzzme.activities;

import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GetTokenResult;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.mad.buzzme.R;
import com.mad.buzzme.model.ServiceProvider;

import java.util.HashMap;
import java.util.Map;

public class InQueueActivity extends AppCompatActivity {

    //Init the View
    private ProgressBar mProgressBar;
    private TextView mGettingInQueueTxt;
    private TextView mSuccessInQueueTxt;
    private ImageView mInQueueImg;
    private FirebaseAuth mAuth;
    private FirebaseUser mCurrentUser;
    private FirebaseFirestore mFireStore;
    private StorageReference mStorage;
    public static final String SERVICE_PROVIDER = "SERVICE PROVIDER";
    public static final String TAG = "SERVICE PROVIDER";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_in_queue);

        //Initialise UI
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);
        mGettingInQueueTxt = (TextView) findViewById(R.id.gettingInQueueTxt);
        mSuccessInQueueTxt = (TextView) findViewById(R.id.successInQueueTxt);
        mInQueueImg = (ImageView) findViewById(R.id.inQueueImg);

        //Initialise backend
        mAuth = FirebaseAuth.getInstance();
        mCurrentUser = mAuth.getCurrentUser();
        mFireStore = FirebaseFirestore.getInstance();

        //Get service provider from the StoreInterFace Fragment
        ServiceProvider serviceProvider = (ServiceProvider) getIntent().getParcelableExtra(SERVICE_PROVIDER);

        if (serviceProvider != null){
            final String spID = serviceProvider.getSpId();
            final String spName = serviceProvider.getSpname();
            final String user_id = mCurrentUser.getUid();
            final String userName = mCurrentUser.getDisplayName();
            final String userImgURL = String.valueOf(mCurrentUser.getPhotoUrl());

            //In this activity the user information will be stored on FireStore Cloud Database waiting for notifications
            final Map<String, Object> userMap = new HashMap<>();
            userMap.put("name", userName);
            userMap.put("userID", user_id);
            userMap.put("userImgUrl", userImgURL);
            mFireStore.collection("ServiceProviders").document(spID).collection("Users").document(user_id).set(userMap).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {

                    FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener(new OnSuccessListener<InstanceIdResult>() {
                        @Override
                        public void onSuccess(InstanceIdResult instanceIdResult) {
                                String token_id = instanceIdResult.getToken();
                                userMap.put("token_id", token_id);
                                //Store user data on the Firestore
                                mFireStore.collection("ServiceProviders").document(spID).collection("Users").document(user_id).update(userMap);
                        }
                    });

                    //update UI
                    mGettingInQueueTxt.setVisibility(View.INVISIBLE);
                    mSuccessInQueueTxt.setVisibility(View.VISIBLE);
                    mProgressBar.setVisibility(View.INVISIBLE);
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.w(TAG, "Error writing document", e);
                }
            });
        }


    }
}
