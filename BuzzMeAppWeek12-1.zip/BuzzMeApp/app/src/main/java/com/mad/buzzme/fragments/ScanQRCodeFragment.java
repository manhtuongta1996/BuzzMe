package com.mad.buzzme.fragments;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.ViewGroup;
import android.app.Activity;
import android.widget.Button;
import android.widget.EditText;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.SparseArray;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.android.gms.vision.barcode.BarcodeDetector;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.mad.buzzme.R;
import com.mad.buzzme.model.ServiceProvider;
import com.mad.buzzme.utilities.DatabaseHelper;

import android.view.SurfaceView;
import android.widget.Toast;

import java.io.IOException;

public class ScanQRCodeFragment extends Fragment {

    //Init views and backends
    private TextView mScanQRcodeTxt;
    SurfaceView cameraPreView;
    private DatabaseHelper mDatabaseHelper;
    private final String SERVICE_PROVIDER = "SERVICE PROVIDER";
    private FirebaseUser mCurrentUser;
    private FirebaseAuth mAuth;

    //Empty constructor required
    public ScanQRCodeFragment() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_scan_qrcode, container, false);

        //Init backend
        mDatabaseHelper = new DatabaseHelper(getActivity());
        mScanQRcodeTxt = (TextView) view.findViewById(R.id.scanQRmsg);
        cameraPreView = (SurfaceView) view.findViewById(R.id.camera_preview);

        createCameraSource();

        mAuth = FirebaseAuth.getInstance();
        mCurrentUser = mAuth.getCurrentUser();

        return view;
    }

    /*
     * This method will open the Camera Source of the device and ready to scan the QR code
     */
    private void createCameraSource() {
        //Init barcode detector
        BarcodeDetector barcodeDetector = new BarcodeDetector.Builder(getActivity()).build();
        final CameraSource cameraSource = new CameraSource.Builder(getActivity(), barcodeDetector)
                .setAutoFocusEnabled(true)
                .setRequestedPreviewSize(1600, 1024)
                .build();

        cameraPreView.getHolder().addCallback(new SurfaceHolder.Callback() {
            @SuppressLint("MissingPermission")
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                if (ActivityCompat.checkSelfPermission(getActivity(), android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                try {
                    cameraSource.start(cameraPreView.getHolder());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                cameraSource.stop();
            }
        });

        barcodeDetector.setProcessor(new Detector.Processor<Barcode>() {
            @Override
            public void release() {

            }

            @Override
            public void receiveDetections(Detector.Detections<Barcode> detections) {
                final SparseArray<Barcode> barcodes = detections.getDetectedItems();
                //When the barcode detects a QR code from the service provider it will put the QR
                //code into an array and check if they are registered service providers
                if(barcodes.size()>0){
                    if (mDatabaseHelper.getAuthorisedSP(barcodes.valueAt(0).displayValue)!= null) {
                            Bundle bundle = new Bundle();
                            bundle.putParcelable(SERVICE_PROVIDER, mDatabaseHelper.getAuthorisedSP(barcodes.valueAt(0).displayValue));
                            Fragment storeInterfaceFragment = new StoreInterfaceFragment();
                            storeInterfaceFragment.setArguments(bundle);
                            FragmentManager fm = getFragmentManager();
                            FragmentTransaction transaction = fm.beginTransaction();
                            //Replace fragment into MenuActivity if service provider found
                            transaction.replace(R.id.content_main, storeInterfaceFragment);
                            transaction.commit();
                            }
                }
            }
        });
    }









}
