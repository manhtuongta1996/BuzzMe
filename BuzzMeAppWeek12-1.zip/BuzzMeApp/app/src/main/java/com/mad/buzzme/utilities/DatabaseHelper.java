package com.mad.buzzme.utilities;

import android.app.Activity;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.mad.buzzme.activities.MainActivity;
import com.mad.buzzme.activities.MenuActivity;
import com.mad.buzzme.model.Request;
import com.mad.buzzme.model.ServiceProvider;

import java.util.ArrayList;

/*
 * This class will act as Database tool, provide database methods
 */
public class DatabaseHelper {

    //Declare variables
    private Activity mActivity;
    private FirebaseAuth mAuth;
    private FirebaseUser mCurrentUser;
    private GoogleSignInClient mGoogleSignInClient;
    FirebaseAuth.AuthStateListener mAuthListener;
    private FirebaseDatabase database;
    private DatabaseReference myRef;
    private ArrayList<ServiceProvider> serviceProviders;
    private ArrayList<Request> requests;


    public DatabaseHelper(Activity activity){
        this.mActivity = activity;
        mAuth = FirebaseAuth.getInstance();
        mCurrentUser = mAuth.getCurrentUser();
        mGoogleSignInClient = GoogleSignIn.getClient(mActivity, gso);
        serviceProviders = new ArrayList<ServiceProvider>();
        requests = new ArrayList<Request>();

    }

    //Google authentication token
    GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken("562998381320-rhfef8jrrjkr0j5mjncpo52ctpgfj18a.apps.googleusercontent.com")
            .requestEmail()
            .build();

    //Check if the user is logged in
    public void authoriseUser() {
        if(!isUserLoggedIn()) {
            mActivity.finish();
            mActivity.startActivity(new Intent(mActivity, MainActivity.class));
            mAuthListener = new FirebaseAuth.AuthStateListener() {
                @Override
                public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                    mActivity.finish();
                    mActivity.startActivity(new Intent(mActivity, MainActivity.class));
                    }
            };
            mAuth.addAuthStateListener(mAuthListener);}
    }

    public boolean isUserLoggedIn() {
        //If not logged in then send back to login screen
        return mAuth.getCurrentUser() != null;

    }

    public String getUserId() {
        return mCurrentUser.getUid();
    }

    /*
     * create fake data
     */
    public void saveServiceProvider(){
        // Fake data
        myRef = FirebaseDatabase.getInstance().getReference("serviceProviders");
        String id = myRef.push().getKey();
        ServiceProvider wonTong = new ServiceProvider(id, "Won Tong Restaurant","https://s3-media4.fl.yelpcdn.com/bphoto/STD286h0X0MCC9yAqCOMUA/l.jpg", "wVIjKhFANVNvrGJ718gTmWJfzeu2");
        myRef.child(id).setValue(wonTong);
        }

        /*
         * get the arraylist of all the registered service providers
         */
        public ArrayList<ServiceProvider> getServiceProviders(){
            myRef = FirebaseDatabase.getInstance().getReference("serviceProviders");
            myRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    serviceProviders.clear();
                    for(DataSnapshot SPsnapshot: dataSnapshot.getChildren()){
                        ServiceProvider sp = SPsnapshot.getValue(ServiceProvider.class);
                        serviceProviders.add(sp);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
            return serviceProviders;
        }

    /*
     * get the registered service providers
     */
        public ServiceProvider getAuthorisedSP(String id){
        Query query = FirebaseDatabase.getInstance().getReference("serviceProviders")
                .orderByChild("spId")
                .equalTo(id);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                serviceProviders.clear();
                if (dataSnapshot.exists()){
                    for(DataSnapshot Spsnapshot: dataSnapshot.getChildren()){
                        ServiceProvider sp = Spsnapshot.getValue(ServiceProvider.class);
                        serviceProviders.add(sp);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
            return serviceProviders.get(0);
        }

}
