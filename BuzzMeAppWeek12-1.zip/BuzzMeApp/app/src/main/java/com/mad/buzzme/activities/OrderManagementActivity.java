package com.mad.buzzme.activities;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.android.gms.common.internal.service.Common;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.jaredrummler.materialspinner.MaterialSpinner;
import com.mad.buzzme.R;
import com.mad.buzzme.interfaces.ItemClickListener;
import com.mad.buzzme.model.Request;
import com.mad.buzzme.viewholders.OrderManagementViewHolder;
import com.mad.buzzme.viewholders.OrderViewHolder;

public class OrderManagementActivity extends AppCompatActivity {

    //Init Views and backends
    public RecyclerView recyclerView;
    public RecyclerView.LayoutManager layoutManager;

    FirebaseDatabase mFirebaseDatabase;
    DatabaseReference myRef;
    private FirebaseAuth mAuth;
    private FirebaseUser mCurrentUser;
    private String spId="";

    MaterialSpinner statusSpinner;

    FirebaseRecyclerAdapter<Request,OrderManagementViewHolder> adapter;
    /*
     *  This activity is built for service provider staff to manage the order comes in, The staff send update the order status through this activity
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_status);

        //Init backend and getting intent from Storeinterface fragment
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        if(getIntent()!=null){spId = getIntent().getStringExtra("spId");}
        myRef = mFirebaseDatabase.getReference().child("serviceProviders").child(spId).child("Requests");
        mAuth = FirebaseAuth.getInstance();
        mCurrentUser = mAuth.getCurrentUser();

        recyclerView = (RecyclerView) findViewById(R.id.listOrders);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        //Invoke method loadOrders() to display all the order that have been placed by the users
        loadOrders(mCurrentUser.getUid());
    }

    /*
     * This method will populate the viewHolder to display all the orders that have been made by the user
     */
    private void loadOrders(String userId) {
        //Setup the adapter, The order is referred to as "Request"
        adapter = new FirebaseRecyclerAdapter<Request, OrderManagementViewHolder>(
                Request.class,
                R.layout.order_management_item,
                OrderManagementViewHolder.class,myRef

        ) {
            @Override
            protected void populateViewHolder(OrderManagementViewHolder viewHolder, Request model, final int position) {
                //Display order information and status
                viewHolder.txtOrderId.setText(adapter.getRef(position).getKey());
                viewHolder.txtOrderStatus.setText(convertCodeToStatus(model.getStatus()));
                viewHolder.txtOrderName.setText(model.getName());

                //Press the "Update" will allow the staff to change the order status by invoking the showUpdateDialog() method
                viewHolder.updateStatusBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showUpdateDialog(adapter.getRef(position).getKey(),adapter.getItem(position));
                    }
                });

                viewHolder.setItemClickListener(new ItemClickListener() {
                   @Override
                    public void onClick(View view, int position, boolean isLongClick) {
                        // fix Crash when click, do nothing
                       registerForContextMenu(view);
                    }
                });

            }
        };
        //listen to changed in Firebase
        adapter.notifyDataSetChanged();
        recyclerView.setAdapter(adapter);
    }

    //Context Menu
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        if(item.getTitle().equals(com.mad.buzzme.Common.Common.UPDATE))
            showUpdateDialog(adapter.getRef(item.getOrder()).getKey(),adapter.getItem(item.getOrder()));
        else if(item.getTitle().equals(com.mad.buzzme.Common.Common.DELETE));
            deleteOrder(adapter.getRef(item.getOrder()).getKey());
        return super.onContextItemSelected(item);
    }
    /*
     * This method will display a Dialog with choices to update the orderstatus
     */
    private void showUpdateDialog(final String key, final Request item) {
        //Building dialog
        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(OrderManagementActivity.this);
        alertDialog.setTitle("Update Order");
        alertDialog.setMessage("Please choose status");

        //inflate Views
       LayoutInflater inflater = this.getLayoutInflater();
        final View view = inflater.inflate(R.layout.update_order, null);

        //add choices to update order status through a spinner
        statusSpinner = (MaterialSpinner) view.findViewById(R.id.statusSpinner);
        statusSpinner.setItems("In Process","Order is ready","Delete");

        alertDialog.setView(view);

        final String localKey = key;
        alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                if(statusSpinner.getSelectedIndex() == 2){
                    deleteOrder(key);
                }else {
                    item.setStatus(String.valueOf(statusSpinner.getSelectedIndex()));

                    myRef.child(localKey).setValue(item);
                }
            }
        });

        alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        alertDialog.show();
    }

    private void deleteOrder(String key) {
        myRef.child(key).removeValue();

    }

    /*
     * Converting the status code to String
     */
    private String convertCodeToStatus(String status) {
        if(status.equals("0")){
            return "In Process";
        } else if(status.equals("1")){
            return "Order is ready";
        } else return "Order placed";
    }
}
