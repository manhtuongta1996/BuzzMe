package com.mad.buzzme.model;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;

public class ServiceProvider implements Parcelable, Comparable<ServiceProvider>{

    private String spId;
    private String spname;
    private String spImgUrl;
    private String staff;

    public ServiceProvider(){
        super();
    }

    public ServiceProvider(String ID, String name, String spImgUrl, String staff){
        super();
        this.spId = ID;
        this.spname = name;
        this.spImgUrl = spImgUrl;
        this.staff = staff;
    }
    public ServiceProvider(Parcel parcel) {
        this.spId = parcel.readString();
        this.spname = parcel.readString();
        this.spImgUrl = parcel.readString();
        this.staff = parcel.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(this.spId);
        parcel.writeString(this.spname);
        parcel.writeString(this.spImgUrl);
        parcel.writeString(this.staff);
    }

    @Override
    public int compareTo(@NonNull ServiceProvider o) {
        return 0;
    }

    public static final Creator<ServiceProvider> CREATOR = new Creator<ServiceProvider>() {
        @Override
        public ServiceProvider createFromParcel(Parcel in) {
            return new ServiceProvider(in);
        }

        @Override
        public ServiceProvider[] newArray(int size) {
            return new ServiceProvider[size];
        }
    };

    public boolean isServiceProvider(String ID){
        return spId.equals(ID);
    }

    public String getSpname(){
        return this.spname;
    }
    public String getStaff(){return this.staff;}
    public String getSpId(){
        return this.spId;
    }
    public String getSpImgUrl() {return this.spImgUrl;}
}
