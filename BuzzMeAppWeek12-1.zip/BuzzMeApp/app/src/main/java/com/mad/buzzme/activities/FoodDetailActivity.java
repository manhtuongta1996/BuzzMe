package com.mad.buzzme.activities;

import android.support.annotation.NonNull;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mad.buzzme.R;
import com.mad.buzzme.databases.Database;
import com.mad.buzzme.model.Food;
import com.mad.buzzme.model.Order;

import org.w3c.dom.Text;

public class FoodDetailActivity extends AppCompatActivity {

    //Initialize Views and backend
    TextView food_name;
    TextView food_price;
    TextView food_description;

    ImageView food_image;
    FloatingActionButton btnCart;
    ElegantNumberButton numberButton;

    String foodId="";
    String spId="";
    FirebaseDatabase mFirebaseDatabase;
    DatabaseReference foodRef;

    Food currentFood;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.food_detail_fixed);

        //Init the backend and getting data from intent from FoodListActivity
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        if(getIntent()!=null){spId = getIntent().getStringExtra("spId");}
        foodRef = mFirebaseDatabase.getReference().child("serviceProviders").child(spId).child("Foods");

        //Init view
        numberButton = (ElegantNumberButton) findViewById(R.id.number_button);
        btnCart = (FloatingActionButton) findViewById(R.id.btnCart);

        //This button will invoke method addtoCart which add the food the user select to the "cart" following SQL format
        btnCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        foodId, currentFood.getName(),
                        numberButton.getNumber(),
                        currentFood.getPrice(),
                        currentFood.getDiscount()
                ));

                Toast.makeText(FoodDetailActivity.this,"Add successfully",Toast.LENGTH_SHORT).show();
            }
        });

        //Init views
        food_description = (TextView) findViewById(R.id.food_description);
        food_name = (TextView) findViewById(R.id.food_name);
        food_price = (TextView) findViewById(R.id.food_price);
        food_image = (ImageView) findViewById(R.id.img_food);

        //get food Id from the content
        if(getIntent() != null){
            foodId = getIntent().getStringExtra("FoodId");
            if(!foodId.isEmpty()){
                getDetailFood(foodId);
            }
        }



    }
    /*
     *  This method will load the detail of the food selected from the food list. The detail is loaded from firebase
     */
    private void getDetailFood(String foodId) {
        foodRef.child(foodId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                currentFood = dataSnapshot.getValue(Food.class);
                //Display food detail to view
                Glide.with(getBaseContext()).load(currentFood.getImage()).into(food_image);
                food_price.setText(currentFood.getPrice());
                food_name.setText(currentFood.getName());
                food_description.setText(currentFood.getDescription());


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
