package com.mad.buzzme.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.mad.buzzme.R;
import com.mad.buzzme.activities.CartActivity;
import com.mad.buzzme.activities.FoodListActivity;

import com.mad.buzzme.interfaces.ItemClickListener;
import com.mad.buzzme.model.Category;
import com.mad.buzzme.model.ServiceProvider;
import com.mad.buzzme.viewholders.MenuViewHolder;

import static com.mad.buzzme.activities.InQueueActivity.SERVICE_PROVIDER;

/*
 * This Fragment will load the menu
 */
public class RestaurantMenuFragment extends Fragment {

    //Init the views and backend
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mCategoryReference;

    private FloatingActionButton fabCart;

    private String serviceProviderId;
    RecyclerView recycler_menu;
    RecyclerView.LayoutManager layoutManager;

    FirebaseRecyclerAdapter<Category, MenuViewHolder> adapter;
    public RestaurantMenuFragment(){
        // Defaut constructor required
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        //Inflate the layout
        View view = inflater.inflate(R.layout.fragment_restaurant_menu, container, false);
        Bundle bundle = this.getArguments();
        if (bundle != null) {
            //Getting service provider from the
            final ServiceProvider serviceProvider = (ServiceProvider) bundle.getParcelable(SERVICE_PROVIDER);
            serviceProviderId = serviceProvider.getSpId();
        }

        //Init the backend
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mCategoryReference = mFirebaseDatabase.getReference().child("serviceProviders").child(serviceProviderId).child("Category");

        //This floating button will take the user to the their carts
        fabCart = view.findViewById(R.id.fabCart);
        fabCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cartIntent = new Intent(getActivity(), CartActivity.class);
                cartIntent.putExtra("spId", serviceProviderId);
                startActivity(cartIntent);
            }
        });

        //load menu
        recycler_menu = (RecyclerView)view.findViewById(R.id.recycler_menu);
        recycler_menu.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getActivity());
        recycler_menu.setLayoutManager(layoutManager);
        loadMenu();


        return view;
    }

    /*
     * The menu will load this is based on the field "Category" on Firebase database
     */
    private void loadMenu() {
        adapter = new FirebaseRecyclerAdapter<Category, MenuViewHolder>(Category.class,R.layout.menu_item,MenuViewHolder.class,mCategoryReference) {
            @Override
            protected void populateViewHolder(MenuViewHolder viewHolder, Category model, int position) {
                //Display the menu
                viewHolder.menuNameTxt.setText(model.getName());
                Glide.with(getActivity()).load(model.getImage()).into(viewHolder.menuImg);
                final Category clickItem = model;
                viewHolder.setItemClickListener(new ItemClickListener() {
                    @Override
                    public void onClick(View view, int position, boolean isLongClick) {
                        Intent foodList = new Intent(getActivity(), FoodListActivity.class);
                        foodList.putExtra("CategoryId", adapter.getRef(position).getKey());
                        foodList.putExtra("spId", serviceProviderId);
                        startActivity(foodList);
                    }
                });
            }
        };
        recycler_menu.setAdapter(adapter);
    }
}
