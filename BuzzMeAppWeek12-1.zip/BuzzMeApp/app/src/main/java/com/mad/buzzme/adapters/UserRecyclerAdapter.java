package com.mad.buzzme.adapters;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.mad.buzzme.R;
import com.mad.buzzme.fragments.QueueFragment;
import com.mad.buzzme.model.Request;
import com.mad.buzzme.model.ServiceProvider;
import com.mad.buzzme.model.User;
import com.mad.buzzme.utilities.DatabaseHelper;

import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.mad.buzzme.activities.InQueueActivity.TAG;

public class UserRecyclerAdapter extends RecyclerView.Adapter<UserRecyclerAdapter.ViewHolder>{

    //Init variable
    private List<User> users;
    private Context context;
    private Fragment mQueueFragment;
    public UserRecyclerAdapter(Context context, List<User> users, Fragment queueFragment){
        this.users = users;
        this.context = context;
        //QueueFragment is involved to provide varibles to this recycler View class
        this.mQueueFragment = queueFragment;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        //Declare views and variables and backends
        private View mView;
        private ImageView mUserImg;
        private TextView mUserName;
        private TextView mStatus;
        private TextView mOrderNumber;

        private String spId;
        private String spName;

        private Button mSendNotifBtn;
        private Button mCancelNotifBtn;
        private FirebaseDatabase mFirebaseDatabase;

        private FirebaseFirestore mFireStore;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;
            //Init Views
            mUserImg = (ImageView) mView.findViewById(R.id.userImgItem);
            mUserName = (TextView) mView.findViewById(R.id.userNameItem);
            mStatus = (TextView) mView.findViewById(R.id.statusTxt);
            mOrderNumber = (TextView) mView.findViewById(R.id.orderNumberTxt);

            mFirebaseDatabase = FirebaseDatabase.getInstance();
            mSendNotifBtn = (Button) itemView.findViewById(R.id.sendNotifBtn);
            mCancelNotifBtn = (Button) mView.findViewById(R.id.cancelNotifBtn);

            //Get service provider idfrom the QueueFragment
            spId = ((QueueFragment) mQueueFragment).spID;

            //Init FireStore
            mFireStore = FirebaseFirestore.getInstance();

            //Get service provider name from the QueueFragment
            spName = ((QueueFragment) mQueueFragment).spName;
            }
    }

    @NonNull
    @Override
    public UserRecyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        //Inflate layout
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.user_in_queue, viewGroup,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final UserRecyclerAdapter.ViewHolder viewHolder, int i) {
        final User currentUser = users.get(i);
        final String spId = ((ViewHolder) viewHolder).spId;
        final String spName = ((ViewHolder)viewHolder).spName;
        viewHolder.mUserName.setText(users.get(i).getUserName());
        ImageView userImg = viewHolder.mUserImg;
        Glide.with(context).load(users.get(i).getUserImgUrl()).into(userImg);
        /*
          * Find out if the order has an order and display the order information on Views
         */
        if(users.get(i).getOrderNumber()!=null){
            //Display order number
            viewHolder.mOrderNumber.setText("Order: "+users.get(i).getOrderNumber());
            //Getting order status
            final DatabaseReference databaseReference= viewHolder.mFirebaseDatabase.getReference("serviceProviders").child(spId).child("Requests").child(users.get(i).getOrderNumber());
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Request request = dataSnapshot.getValue(Request.class);
                    //If the order status is "Ready" this the text display order number will turn green
                    if (request != null && request.getStatus().equals("1")){
                        viewHolder.mOrderNumber.setTextColor(Color.GREEN);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

        //Pressing "Send" button will send the notification to the user
        ((ViewHolder) viewHolder).mSendNotifBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Notification message
                String message = "Your turn is being called !!";

                Map<String, Object> notificationMessage = new HashMap<>();
                notificationMessage.put("message", message);
                notificationMessage.put("spName", spName); //delete if error
                notificationMessage.put("from", currentUser.getUserID());

                //Put Notification to FireStore
                ((ViewHolder)viewHolder).mFireStore.collection("ServiceProviders")
                        .document(spId)
                        .collection("Users")
                        .document(currentUser.getUserID())
                        .collection("Notifications").add(notificationMessage).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        //Set the notification status displayed in the user item layout
                        viewHolder.mStatus.setText(R.string.sent_notification_status);
                    }
                });
            }
        });

        //This "Cancel" button will delete the user from the queue
        ((ViewHolder) viewHolder).mCancelNotifBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ViewHolder)viewHolder).mFireStore.collection("ServiceProviders")
                        .document(spId)
                        .collection("Users")
                        .document(currentUser.getUserID())
                        .delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully deleted!");
                        users.remove(currentUser);
                        notifyDataSetChanged();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error deleting document", e);
                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return users.size();
    }


}
