package com.mad.buzzme.activities;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.mad.buzzme.R;
import com.mad.buzzme.databases.Database;
import com.mad.buzzme.model.Order;
import com.mad.buzzme.model.Request;
import com.mad.buzzme.viewholders.CartAdaper;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import info.hoang8f.widget.FButton;

public class CartActivity extends AppCompatActivity {

    //Initialize Views, Firebase and Authentication
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;

    FirebaseDatabase mFirebaseDatabase;
    DatabaseReference myRef;
    private FirebaseFirestore mFireStore;

    private FirebaseAuth mAuth;
    private FirebaseUser mCurrentUser;

    private String spId;
    TextView txtTotalPrice;
    Button btnPlace;

    List<Order> cart = new ArrayList<>();

    CartAdaper adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        //Getting data about service provider from restaurant menu
        spId = getIntent().getStringExtra("spId");
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        myRef = mFirebaseDatabase.getReference().child("serviceProviders").child(spId).child("Requests");

        //Init backend
        mAuth = FirebaseAuth.getInstance();
        mCurrentUser = mAuth.getCurrentUser();
        mFireStore = FirebaseFirestore.getInstance();

        recyclerView = (RecyclerView)findViewById(R.id.listCart);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        txtTotalPrice = (TextView) findViewById(R.id.total);

        //When pressing Button "Place order" the user order will be stored in firestore and the user will be send to OrderStatus activity for further update
        btnPlace = (Button)findViewById(R.id.btnPlaceOrder);
        btnPlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Request request = new Request(mCurrentUser.getUid()
                        , mCurrentUser.getDisplayName()
                        ,txtTotalPrice.getText().toString()
                        ,cart);
                //Order Id is generated based on the current timestamp to avoid duplication
                final String orderId = String.valueOf(System.currentTimeMillis());
                myRef.child(orderId)
                        .setValue(request);
                new Database(getBaseContext()).cleanCart();
                Toast.makeText(CartActivity.this, "Thank you for ordering", Toast.LENGTH_SHORT).show();

                // Write order in firestore
                if(spId != null){
                    final String user_id = mCurrentUser.getUid();
                    final String userName = mCurrentUser.getDisplayName();
                    final String userImgURL = String.valueOf(mCurrentUser.getPhotoUrl());
                    //Hash map for user modelling
                    final Map<String, Object> userMap = new HashMap<>();
                    userMap.put("name", userName);
                    userMap.put("userID", user_id);
                    userMap.put("userImgUrl", userImgURL);
                    userMap.put("orderNumber",orderId);
                    mFireStore.collection("ServiceProviders").document(spId).collection("Users").document(user_id).set(userMap).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {

                            FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener(new OnSuccessListener<InstanceIdResult>() {
                                @Override
                                public void onSuccess(InstanceIdResult instanceIdResult) {
                                    //Get device token from the user
                                    String token_id = instanceIdResult.getToken();
                                    userMap.put("token_id", token_id);
                                    mFireStore.collection("ServiceProviders").document(spId).collection("Users").document(user_id).update(userMap);
                                }
                            });

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(getBaseContext(), "Writing order successfully", Toast.LENGTH_SHORT).show();
                        }
                    });

                }

                //Send user to OrderstatusActivity
                Intent orderStatusIntent = new Intent(CartActivity.this, OrderStatusActivity.class);
                orderStatusIntent.putExtra("spId", spId);
                startActivity(orderStatusIntent);

            }
        });
        //invoke method loadListFood to display the list of foods the user added to the cart
        loadListFood();
    }

    /*
     *  Load list of food from the SQL database saved inside the user device
     */
    private void loadListFood() {
        cart = new Database(this).getCarts();
        // the order in stored in SQL Database so that it's saved inside the user device
        adapter = new CartAdaper(cart,this);
        recyclerView.setAdapter(adapter);

        //Calculate total price
        int total = 0;
        for(Order order: cart){
            total+=(Integer.parseInt(order.getPrice())) * (Integer.parseInt(order.getQuantity()));
            Locale locale = new Locale("en","US");
            NumberFormat fmt = NumberFormat.getCurrencyInstance(locale);

            txtTotalPrice.setText(fmt.format(total));
        }
    }
}
