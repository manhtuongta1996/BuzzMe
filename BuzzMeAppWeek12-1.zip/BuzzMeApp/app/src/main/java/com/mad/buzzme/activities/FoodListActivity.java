package com.mad.buzzme.activities;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.mad.buzzme.R;
import com.mad.buzzme.interfaces.ItemClickListener;
import com.mad.buzzme.model.Food;
import com.mad.buzzme.viewholders.FoodViewHolder;

public class FoodListActivity extends AppCompatActivity {

    //Init views and backends
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;

    FirebaseDatabase mFirebaseDatabase;
    DatabaseReference foodRef;
    FloatingActionButton fabCart;

    String categoryId = "";
    String spId = "";

    //adapter to display foods
    FirebaseRecyclerAdapter<Food, FoodViewHolder> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_list);

        //Init backend
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        if(getIntent()!=null){spId = getIntent().getStringExtra("spId");}
        foodRef = mFirebaseDatabase.getReference().child("serviceProviders").child(spId).child("Foods");

        //This floating button will the users to their carts
        fabCart = findViewById(R.id.fabCart);
        fabCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cartIntent = new Intent(FoodListActivity.this, CartActivity.class);
                cartIntent.putExtra("spId", spId);
                startActivity(cartIntent);
            }
        });

        //Recycler view for the list
        recyclerView = (RecyclerView) findViewById(R.id.recycler_food);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        //Get intent from Restaurant Menu
        if(getIntent() != null){
            categoryId = getIntent().getStringExtra("CategoryId");
            if(!categoryId.isEmpty() && categoryId != null){
                //Invoke method loadListFood() to load food detail from Firebase
                loadListFood(categoryId);
            }
        }

    }

    /*
     * This method will list the food based on the category the user selected from the Restaurant Menu Fragment
     */
    private void loadListFood(String categoryId) {
        //setup the adapter of FoodViewHolder
        adapter = new FirebaseRecyclerAdapter<Food, FoodViewHolder>(Food.class,
                R.layout.food_item,
                FoodViewHolder.class,
                foodRef.orderByChild("MenuId").equalTo(categoryId)) {
            @Override
            protected void populateViewHolder(FoodViewHolder viewHolder, Food model, int position) {
                viewHolder.food_name.setText(model.getName());
                Glide.with(getBaseContext()).load(model.getImage()).into(viewHolder.food_image);

                final Food local = model;
                viewHolder.setItemClickListener(new ItemClickListener() {
                    @Override
                    public void onClick(View view, int position, boolean isLongClick) {
                        //Transfer to the user to the list of food based on the category
                        Intent foodDetail = new Intent(FoodListActivity.this, FoodDetailActivity.class);
                        foodDetail.putExtra("FoodId", adapter.getRef(position).getKey());
                        foodDetail.putExtra("spId", spId);
                        startActivity(foodDetail);
                    }
                });
            }
        };

        //set Adapter
        recyclerView.setAdapter(adapter);
    }
}
