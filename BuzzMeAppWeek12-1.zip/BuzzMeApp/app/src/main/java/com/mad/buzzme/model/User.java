package com.mad.buzzme.model;

public class User {
    String name;
    String userID;
    String userImgUrl;
    String orderNumber;

    public User(){

    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getUserName() {
        return name;
    }

    public void setUserName(String userName) {
        this.name = userName;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserImgUrl() {
        return userImgUrl;
    }

    public void setUserImgUrl(String userImgUrl) {
        this.userImgUrl = userImgUrl;
    }

    public User(String userName, String userID, String userImgUrl) {
        this.name = userName;
        this.userID = userID;
        this.userImgUrl = userImgUrl;
    }
}
