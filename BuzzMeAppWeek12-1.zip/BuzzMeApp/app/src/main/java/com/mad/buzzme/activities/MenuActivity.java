package com.mad.buzzme.activities;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.mad.buzzme.R;
import com.mad.buzzme.fragments.AboutFragment;
import com.mad.buzzme.fragments.QueueFragment;
import com.mad.buzzme.fragments.ScanQRCodeFragment;
import com.mad.buzzme.utilities.DatabaseHelper;

public class MenuActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    // Declare UI, database and navigation view
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    private NavigationView mNavView;
    private FirebaseAuth mAuth;
    private GoogleSignInClient mGoogleSignInClient;
    private DatabaseHelper mDatabaseHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);



        //Initialize Database Helper
        mDatabaseHelper = new DatabaseHelper(this);

        // Build a GoogleSignInClient with the options specified by gso.
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        // Initialize mAuth
        mAuth = FirebaseAuth.getInstance();



        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mToggle = new ActionBarDrawerToggle(this, mDrawerLayout,R.string.open_navigation_drawer, R.string.close_navigation_drawer);

        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // set default fragment to ScanQRCode fragment
        setFragment(new ScanQRCodeFragment());

        //setup Navigation Drawer listener
        mNavView = (NavigationView) findViewById(R.id.nav_view);
        mNavView.setNavigationItemSelectedListener(this);



    }

    @Override
    protected void onStart() {
        super.onStart();
        //Check if User is logged in
        mDatabaseHelper.authoriseUser();
        //mDatabaseHelper.saveServiceProvider();
    }
    GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken("562998381320-rhfef8jrrjkr0j5mjncpo52ctpgfj18a.apps.googleusercontent.com")
            .requestEmail()
            .build();
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(mToggle.onOptionsItemSelected(item)){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    /**
     * Set fragment to replace content_main layout
     * @param fragment
     */
    public void setFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.content_main, fragment)
                .commit();
    }

    /**
     * Navigation Drawer select action for each item
     * @param menuItem
     * @return
     */
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        int id = menuItem.getItemId();
        switch (id) {
            case R.id.nav_logout:
                // Application logout
                mAuth.signOut();
                // Google sign out
                mGoogleSignInClient.signOut()
                        .addOnCompleteListener(this, new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                startActivity(new Intent(MenuActivity.this, MainActivity.class));
                            }
                        });
                break;
            case R.id.nav_about:
                setFragment(new AboutFragment());
                break;
            case R.id.nav_order:
                setFragment(new ScanQRCodeFragment());
                break;
            case R.id.nav_reservation:
                setFragment(new ScanQRCodeFragment());
                break;
        }
        return true;
    }
}
