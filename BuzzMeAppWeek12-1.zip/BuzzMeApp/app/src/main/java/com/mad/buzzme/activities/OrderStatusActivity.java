package com.mad.buzzme.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.android.gms.common.internal.service.Common;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.mad.buzzme.R;
import com.mad.buzzme.interfaces.ItemClickListener;
import com.mad.buzzme.model.Request;
import com.mad.buzzme.viewholders.OrderViewHolder;

public class OrderStatusActivity extends AppCompatActivity {
    //Init Views and backends
    public RecyclerView recyclerView;
    public RecyclerView.LayoutManager layoutManager;

    FirebaseDatabase mFirebaseDatabase;
    DatabaseReference myRef;
    private FirebaseAuth mAuth;
    private FirebaseUser mCurrentUser;
    private String spId="";

    FirebaseRecyclerAdapter<Request,OrderViewHolder> adapter;
    /*
     *  This activity is built for users to manage the order the have placed
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_status);

        //Init backend and getting intent
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        if(getIntent()!=null){spId = getIntent().getStringExtra("spId");}
        myRef = mFirebaseDatabase.getReference().child("serviceProviders").child(spId).child("Requests");
        mAuth = FirebaseAuth.getInstance();
        mCurrentUser = mAuth.getCurrentUser();

        recyclerView = (RecyclerView) findViewById(R.id.listOrders);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        //Invoke method loadOrders() to display all the order that have been placed by the users
        loadOrders(mCurrentUser.getUid());
    }

    /*
     * This method will populate the viewHolder to display all the orders that have been made by the user
     */
    private void loadOrders(String userId) {
        //Setup the adapter, The order is referred to as "Request"
        adapter = new FirebaseRecyclerAdapter<Request, OrderViewHolder>(
                Request.class,
                R.layout.order_layout,
                OrderViewHolder.class,myRef.orderByChild("userId").equalTo(userId)

        ) {
            @Override
            protected void populateViewHolder(OrderViewHolder viewHolder, Request model, int position) {
                //Display order information and status
                viewHolder.txtOrderId.setText(adapter.getRef(position).getKey());
                viewHolder.txtOrderStatus.setText(convertCodeToStatus(model.getStatus()));
                viewHolder.txtOrderName.setText(model.getName());

                viewHolder.setItemClickListener(new ItemClickListener() {
                    @Override
                    public void onClick(View view, int position, boolean isLongClick) {
                        //Do nothing to prevent crash
                    }
                });
            }
        };
        recyclerView.setAdapter(adapter);
    }

    /*
     * Converting the status code to String
     */
    private String convertCodeToStatus(String status) {
        if(status.equals("0")){
            return "In Process";
        } else if(status.equals("1")){
            return "Order is ready";
        } else return "Order placed";
    }
}
